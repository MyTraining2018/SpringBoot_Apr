package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2SpringBootRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day2SpringBootRestApplication.class, args);
	}
}
