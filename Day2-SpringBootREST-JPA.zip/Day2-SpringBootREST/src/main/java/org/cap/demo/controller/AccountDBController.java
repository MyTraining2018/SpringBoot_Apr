package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Account;
import org.cap.demo.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v2/api")
public class AccountDBController {

	
	@Autowired
	private IAccountService accountDBService;
	
	
	@GetMapping("/accountbalance/{balance}")
	public ResponseEntity<List<Account>> filterByBalance(
		
			@PathVariable("balance") Double balance
			) {
		List<Account> accounts= accountDBService.filterAllBalances(balance);
				
		if( accounts==null) {
			return new ResponseEntity("Sorry! AccountNumber Not Found!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	@GetMapping("/accounts/{accounttype}/{accountname}")
	public ResponseEntity<List<Account>> findAccountByNameOrType(
			@PathVariable("accounttype") String accounttype,
			@PathVariable("accountname") String accountname
			) {
		List<Account> accounts= accountDBService
				.findByAccountTypeOrAccountNameOrderByAccountNoDesc(accounttype, accountname);
		if( accounts==null) {
			return new ResponseEntity("Sorry! AccountNumber Not Found!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	
	@GetMapping("/accounttype/{accounttype}")
	public ResponseEntity<List<Account>> findAccountById(
			@PathVariable("accounttype") String accounttype) {
		List<Account> accounts= accountDBService.findByAccountType(accounttype);
		if( accounts==null) {
			return new ResponseEntity("Sorry! AccountNumber Not Found!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	//-----------------------------CRUD operation --------------------------------------
	
	@GetMapping("/accounts")
	public ResponseEntity<List<Account>> getAllAccounts() {
		List<Account> accounts= accountDBService.getAllAccounts();
		if(accounts.isEmpty() || accounts==null) {
			return new ResponseEntity("Sorry! Accounts Not available!",HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	@GetMapping("/accounts/{accountNo}")
	public ResponseEntity<Account> findAccountById(@PathVariable("accountNo") Integer accountNo) {
		Account accounts= accountDBService.findAccountById(accountNo);
		if( accounts==null) {
			return new ResponseEntity("Sorry! AccountNumber Not Found!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Account>(accounts,HttpStatus.OK);
	}
	
	
	@DeleteMapping("/accounts/{accountNo}")
	public ResponseEntity<List<Account>> deleteAccountById(@PathVariable("accountNo") Integer accountNo) {
		
		List<Account> accounts= accountDBService.deleteAccount(accountNo);
		
		if( accounts==null) {
			return new ResponseEntity("Sorry! AccountNumber Not Found!",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	@PostMapping("/accounts")
	public ResponseEntity<List<Account>> createAccount(
			@RequestBody Account account){
		
		
		List<Account> accounts=accountDBService.createAccount(account);
		
		if(accounts.isEmpty() || accounts==null) {
			return new ResponseEntity("Sorry! Accounts Not available!",HttpStatus.CONFLICT);
		}
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
		
		
	}
	
	
	
	
	
	
	
	
	
}
