package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.model.Account;
import org.springframework.stereotype.Repository;

@Repository("accountDao")
public class AccountDaoImpl implements IAccountDao{
	private static AtomicInteger accId=new AtomicInteger(0);
	
	private static List<Account> accounts=dummyAccountDetails();
	
	
	public static List<Account> dummyAccountDetails(){
		List<Account> accounts=new ArrayList<>();
		
		accounts.add(new Account(accId.incrementAndGet(), "Tom", "Savings", new Date(),3000));
		accounts.add(new Account(accId.incrementAndGet(), "Jerry", "Savings", new Date(),9000));
		accounts.add(new Account(accId.incrementAndGet(), "Jack", "Current", new Date(2001,4,23),12000));
		accounts.add(new Account(accId.incrementAndGet(), "Emi", "Current", new Date(),4500));
		accounts.add(new Account(accId.incrementAndGet(), "Tim", "Loan", new Date(2001,3,12),300000));
		accounts.add(new Account(accId.incrementAndGet(), "Jim", "Loan", new Date(),300000));
		accounts.add(new Account(accId.incrementAndGet(), "Thomson", "Savings", new Date(2001,3,12),2300));
		
		
		return accounts;
	}
	

	@Override
	public List<Account> getAllAccounts() {
		
		return accounts;
	}


	@Override
	public Account findAccountById(int accountNo) {
	
		for(Account account:accounts)
		{
			if(account.getAccountNo()==accountNo)
				return account;
		}
		return null;
	}


	@Override
	public List<Account> deleteAccount(int accountNo) {
		boolean flag=true;
		
		Iterator<Account> iterator= accounts.iterator();
		
		while(iterator.hasNext()) {
			Account account=iterator.next();
			
			if(account.getAccountNo()==accountNo) {
				flag=false;
				iterator.remove();
			}
		}
		
		if(flag==true)
			return null;
		else
			return accounts;
	}


	@Override
	public List<Account> createAccount(Account account) {
		accounts.add(account);
		return accounts;
	}

}



















