package org.cap.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository("accountDBDao")
@Transactional
public interface IAccountDBDao extends JpaRepository<Account, Integer>{
	
	
	
	public List<Account> findByAccountType(String accountType);
	public List<Account> findByAccountTypeOrAccountNameOrderByAccountNoDesc(String accountType,String accountName);
	
	
	
	@Query("select account from Account account where account.balance>=?")
	public List<Account> filterAllBalances(double balance);

}
