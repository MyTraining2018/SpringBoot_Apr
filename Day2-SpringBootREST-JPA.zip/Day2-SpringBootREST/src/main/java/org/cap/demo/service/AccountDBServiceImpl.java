package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAccountDBDao;
import org.cap.demo.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountDBService")
public class AccountDBServiceImpl implements IAccountService{
	@Autowired
	private IAccountDBDao accountDBDao;

	@Override
	public List<Account> getAllAccounts() {
		
		return accountDBDao.findAll();
	}

	@Override
	public Account findAccountById(int accountNo) {
		
		return accountDBDao.findOne(accountNo);
	}

	@Override
	public List<Account> deleteAccount(int accountNo) {
		accountDBDao.delete(accountNo);
		
		return  accountDBDao.findAll();
	}

	@Override
	public List<Account> createAccount(Account account) {
		 accountDBDao.save(account);
		return  accountDBDao.findAll();
	}

	@Override
	public List<Account> findByAccountType(String accountType) {
		
		return accountDBDao.findByAccountType(accountType);
	}

	@Override
	public List<Account> findByAccountTypeOrAccountNameOrderByAccountNoDesc(String accountType, String accountName) {
		// TODO Auto-generated method stub
		return accountDBDao.findByAccountTypeOrAccountNameOrderByAccountNoDesc(accountType, accountName);
	}

	@Override
	public List<Account> filterAllBalances(double balance) {
		
		return accountDBDao.filterAllBalances(balance);
	}
}
