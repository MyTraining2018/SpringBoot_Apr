package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Account;

public interface IAccountService {
	
	public List<Account> getAllAccounts();
	public Account findAccountById(int accountNo);
	public List<Account> deleteAccount(int accountNo);
	public List<Account> createAccount(Account account);
	

	public List<Account> findByAccountType(String accountType);
	public List<Account> findByAccountTypeOrAccountNameOrderByAccountNoDesc(String accountType,String accountName);
	
	public List<Account> filterAllBalances(double balance);

}
