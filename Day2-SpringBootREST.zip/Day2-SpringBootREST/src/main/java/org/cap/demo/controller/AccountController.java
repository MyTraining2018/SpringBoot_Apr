package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Account;
import org.cap.demo.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/api")
public class AccountController {

	@Autowired
	private IAccountService accountService;
	
	@GetMapping("/accounts")
	public ResponseEntity<List<Account>> getAllAccounts() {
		List<Account> accounts= accountService.getAllAccounts();
		if(accounts.isEmpty() || accounts==null) {
			return new ResponseEntity("Sorry! Accounts Not available!",HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	@GetMapping("/accounts/{accountNo}")
	public ResponseEntity<Account> findAccountById(@PathVariable("accountNo") Integer accountNo) {
		Account accounts= accountService.findAccountById(accountNo);
		if( accounts==null) {
			return new ResponseEntity("Sorry! AccountNumber Not Found!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Account>(accounts,HttpStatus.OK);
	}
	
	
	@DeleteMapping("/accounts/{accountNo}")
	public ResponseEntity<List<Account>> deleteAccountById(@PathVariable("accountNo") Integer accountNo) {
		
		List<Account> accounts= accountService.deleteAccount(accountNo);
		
		if( accounts==null) {
			return new ResponseEntity("Sorry! AccountNumber Not Found!",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	@PostMapping("/accounts")
	public ResponseEntity<List<Account>> createAccount(
			@RequestBody Account account){
		
		
		List<Account> accounts=accountService.createAccount(account);
		
		if(accounts.isEmpty() || accounts==null) {
			return new ResponseEntity("Sorry! Accounts Not available!",HttpStatus.CONFLICT);
		}
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
		
		
	}
	
	
	
	
	
	
	
	
	
	
}















