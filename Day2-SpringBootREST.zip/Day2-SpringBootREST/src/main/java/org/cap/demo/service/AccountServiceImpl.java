package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAccountDao;
import org.cap.demo.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountService")
public class AccountServiceImpl implements IAccountService {
	
	@Autowired
	private IAccountDao accountDao;

	@Override
	public List<Account> getAllAccounts() {
		
		return accountDao.getAllAccounts();
	}

	@Override
	public Account findAccountById(int accountNo) {
		
		return accountDao.findAccountById(accountNo);
	}

	@Override
	public List<Account> deleteAccount(int accountNo) {
		
		return accountDao.deleteAccount(accountNo);
	}

	@Override
	public List<Account> createAccount(Account account) {
	
		return accountDao.createAccount(account);
	}

}
