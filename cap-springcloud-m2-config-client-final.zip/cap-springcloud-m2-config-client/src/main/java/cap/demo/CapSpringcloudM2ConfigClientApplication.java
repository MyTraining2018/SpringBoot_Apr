package cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapSpringcloudM2ConfigClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapSpringcloudM2ConfigClientApplication.class, args);
	}
}
